<?php defined("SYSPATH") or die("No direct script access.") ?>

<div id="none" class="g-module-status g-warning g-block">
  <h3> <?= t("No active toolkit") ?> </h3>
  <p>
    <?= t("We were unable to detect a graphics program.  You must install one of the toolkits below in order to use many Gallery features.") ?>
  </p>
</div>
