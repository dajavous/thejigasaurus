<?php defined("SYSPATH") or die("No direct script access.") ?>
<?php echo Kohana_Exception::text($e), "\n";

