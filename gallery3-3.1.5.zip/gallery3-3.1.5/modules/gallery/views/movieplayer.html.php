<?php defined("SYSPATH") or die("No direct script access.") ?>
<div <?= html::attributes($div_attrs) ?>>
  <video <?= html::attributes($source_attrs) ?> <?= html::attributes($video_attrs) ?>></video>
</div>
